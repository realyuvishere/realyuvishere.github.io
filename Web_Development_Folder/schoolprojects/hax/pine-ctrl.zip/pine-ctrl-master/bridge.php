<?php

if($authenticated == '1'){
		if (empty($_REQUEST["m"])) {
		// if no parameter, print information
		echo "<br><pre>User \"" . $ar_id . "\" logged in</pre><br><hr>";
		include 'p_info.html'; //README html file
	} else{
		// if parameter exist, run operations
		include 'p_com1.php'; //this file contains all operations
	}
}
<?php
if($authenticated != '1'){
	echo "auth error!";
	exit;
}
/*
LOGGING SYSTEM
*/
if ($_REQUEST["m"]=='l') {
	include 'p_com2.php'; //this file contains logging operations
}

/*
	DELETE FILE FROM ./raya/ DIRECTORY
*/
if ($_REQUEST["m"]=='delete') {
	$file = "./raya/" . $_REQUEST["v"];
	if (file_exists($file)) {
		unlink($file);
				echo "SUCCESS: $file has been deleted!";
	}else{
		echo "ERROR: $file cannot be found";
	}
}
/*
	CHECK IF FILE EXISTS IN ./raya/ DIRECTORY
*/
if ($_REQUEST["m"]=='check') {
	$file = "./raya/" . $_REQUEST["v"];
	if (file_exists($file)) {
		echo "SUCCESS: $file exists!";
	}else{
		echo "ERROR: $file cannot be found";
	}
}
/*
	ECHO STRING
*/
if ($_REQUEST["m"]=='echo') {
	$echo=$_REQUEST["v"];
	echo "ECHO: $echo";
}

/*
	GET IP ADDRESS
*/
if ($_REQUEST["m"]=='ip') {
echo "IP: " . $_SERVER['REMOTE_ADDR'];
}

/*
	UPLOAD FILE
*/

if ($_REQUEST["m"]=='upload') {
	echo '<form action="" method="POST" enctype="multipart/form-data">
	<input type="file" name="rayaf" />
	<input type="submit"/>
	</form>';
}

if(isset($_FILES['rayaf'])){
	$errors= array();
	$file_name = $_FILES['rayaf']['name'];
	$file_size =$_FILES['rayaf']['size'];
	$file_tmp =$_FILES['rayaf']['tmp_name'];
	$file_type=$_FILES['rayaf']['type'];   
	move_uploaded_file($file_tmp,"raya/".$file_name);
	echo "SUCCESS: File uploaded!";
}

/*
	DOWNLOAD FILE
*/
if ($_REQUEST["m"]=='down') {
	$file = "./raya/" . $_REQUEST["v"];
	if (file_exists($file)) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="'.basename($file).'"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    readfile($file);
	}else{
		echo "ERROR: $file cannot be found";
	}
}
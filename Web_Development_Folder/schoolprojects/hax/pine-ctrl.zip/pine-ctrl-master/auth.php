<?php
/* The following array contains authentication info
"device_id"=>"auth_key"
*/
$autharray = array(
"node_1"	=>"randompass1",
"node_2"	=>"thisisstupid",
"node_3"	=>"rahul_got_no_sex",
"rout_mon"	=>"ily.princess",
"serv_ftp"	=>"RaYa_all_the_wayy",
"serv_ssh"	=>"i.like.shreya"
);


/*---------*/

$ar_id = $_REQUEST['id'];
$ar_key = $_REQUEST['key'];

if (!empty($_REQUEST["id"])) {
	if (array_key_exists($ar_id,$autharray)){

		if ($ar_key === $autharray[$ar_id]){
			//AUTHENTICATED!
			$authenticated=1;
			include 'bridge.php';
			} else {
			echo "Wrong auth key, brooooo";
		}

	} else {
		echo "Invalid device ID, u getit? Go check 'em auth keys...";
	}
} else {
	?>
	
<!DOCTYPE html>
<html>
<head>
<title>LOGIN | pine+ctrl</title>
</head>
<body><code>
            <form method="POST" action="#">
            Device ID / USER:&nbsp;&nbsp;<input type="text" name="id"></input><br/>
            Auth Key / PASS&nbsp;:&nbsp;&nbsp;<input type="password" name="key"></input><br/>
            <input type="submit" name="submit" value="Go"></input>
            </form>
			<br>Demo id: <i><b>node_1</b></i>; Demo key: <i><b>randompass1</b></i><br>
			<a href="p_info.html">help</a><br>
</code>
</body>
</html>
    <?php
}



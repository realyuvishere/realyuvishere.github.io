<?php
/*
            _                       _        _ 
__/\___ __ (_)_ __   ___   _    ___| |_ _ __| |
\    / '_ \| | '_ \ / _ \_| |_ / __| __| '__| |
/_  _\ |_) | | | | |  __/_   _| (__| |_| |  | |
  \/ | .__/|_|_| |_|\___| |_|  \___|\__|_|  |_|
     |_|                                       

!!! https://github.com/rahuldottech/pine-ctrl 
^ To know how to make this work :)
https://www.rahul.tech/
*/

/*-- SECURITY & CONFIGURATION --*/

//disabling PHP errors for production servers
//error_reporting(E_ERROR | E_PARSE);

//cookies
ini_set('session.cookie_httponly', 1 ); //Prevent XSS
ini_set('session.use_only_cookies', 1 ); //Prevent cookie as GET

//HTTPS
$httpsenforce = '1'; //enforce HTTPS and HTTPS cookies

//timezone - add/subtract second delay 
$date = date('d/m/y g:i A', time() + 0); 

//log file - where all logs are stored
$logfile = 'p_logs.txt';


/*-- PRE SCRIPT --*/

//enforce HTTPS
if($httpsenforce === '1'){
if(empty($_SERVER["HTTPS"]) || $_SERVER["HTTPS"] !== "on")
{
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]); //redirect to HTTPS
    ini_set('session.cookie_secure', 1 ); //Enforce HTTPS for cookies
	exit();
}}

/*--- MAIN SCRIPT --*/

// check if "m" parameter is provided

include 'auth.php'; //authenticate user

	





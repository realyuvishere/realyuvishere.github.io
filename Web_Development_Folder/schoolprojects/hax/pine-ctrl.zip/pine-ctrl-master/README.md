# pine-ctrl
Centralized logging system for IoT devices and remote systems

```
            _                       _        _ 
__/\___ __ (_)_ __   ___   _    ___| |_ _ __| |
\    / '_ \| | '_ \ / _ \_| |_ / __| __| '__| |
/_  _\ |_) | | | | |  __/_   _| (__| |_| |  | |
  \/ | .__/|_|_| |_|\___| |_|  \___|\__|_|  |_|
     |_|                                       
```
## What is this?
<i><b>pine+ctrl</b></i> is a centralised IoT control system.
It can:
<ul>
<li>Store collated and combined status logs from multiple devices.</li>
<li>Act as a file upload/download system for centralised cloud file storage.</li>
<li>Act as a file fetching proxy.</li>
<li>Act as a gateway to the internet from an intranet.</li>
<li>And a lot more!</li>
</ul>
<i><b>Note: </b>In accordance with HTTP standards, use GET requests to fetch data, POST to submit and alter data to/on the server.</i>

## Requirements

  - PHP 5.6+
  - 2 MiB disk space :P

## Installation
 - Download the files of this repo and upload them to a server.
 - Edit the file `auth.php` and add a login for each device which will be accessing and making use of the system.
 
-----

## Syntaxxx

## Authentication
Every request sent to the server must contain the following parameters: `id=[device_id]` and `key=[auth_key]`.

#### Examples
**Browser GET:**  
```
http://localhost/?id=node_1&key=randompass1
```

**curl POST:**
```
curl --data "id=node_1&key=randompass1" http://localhost/
```

<h2>File operations</h2>
<h3>Requests:</h3>
<ul>
<li>Upload file:&nbsp;&nbsp; <output>m=<b><i>upload</i></b>  v=<b><i>[file_name]</i></b></output></li>
<li>Check  file:&nbsp;&nbsp;&nbsp; <output>m=<b><i>check</i></b>   &nbsp;v=<b><i>[file_name]</i></b></output></li>
<li>Download  file: <output>m=<b><i>down</i></b>&nbsp;&nbsp;&nbsp;v=<b><i>[file_name]</i></b></output></li>
<li>Delete file: &nbsp;&nbsp;<output>m=<b><i>delete</i></b>  v=<b><i>[file_name]</i></b></output></li>
</ul>
<h3>Example:</h3>
<b>GET request: </b><output>?m=check&v=info.txt</output><br>
<b>Possible outputs: </b><br>
<ol>
<li><output>SUCCESS: ./raya/info.txt has been deleted!</output></li>
<li><output>ERROR: ./raya/info.txt cannot be found</output></li>
</ol>
<h3>Files:</h3>
All files are stored in the <output>./raya/</output> directory.<br>
File uploads must be through multipart POST form data.
<h3>Extra:</h3>
Just <output>?m=upload</output> will display an HTML upload form.<br><br>
<hr>
<h2>Misc. operations</h2>
<h3>Requests:</h3>
<li>Echo text: &nbsp;&nbsp;<output>m=<b><i>echo</i></b>    v=<b><i>[text]</i></b></output></li>
<li>Echo IP adr: <output>m=<b><i>ip</i></b></output></li>

